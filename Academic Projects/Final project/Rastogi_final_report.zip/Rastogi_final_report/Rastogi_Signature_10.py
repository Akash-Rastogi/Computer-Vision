'''
============================================================================
Following python code is for 
"Vision Based Fingertip Tracking for signature construction and verification"

Youtube Link : https://youtu.be/ej7SOJg8284

Author : Akash Rastogi
Date   : 14th April 2017
============================================================================
'''

import cv2, gc
import numpy as np
from dtw import dtw

# Method to track fingertip using Optical Flow
def track_fingertip(fingertip, frame, old_gray, mask, lk_params, signature, signature_frames, signature_x, signature_y):
    frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    color = (255, 255, 255)

    # Calculate optical flow : Lucas-Kanade method with pyramids
    next_point, status, error = cv2.calcOpticalFlowPyrLK(old_gray, frame_gray, fingertip, None, **lk_params)

    # Select good points, when status is 1
    good_new = next_point[status == 1]
    good_old = fingertip[status == 1]

    # Draw the tracks
    for i, (new, old) in enumerate(zip(good_new, good_old)):
        a, b = new.ravel()
        c, d = old.ravel()
        mask = cv2.line(mask, (a, b), (c, d), color, 2)
        signature = cv2.line(mask, (a, b), (c, d), color, 5)
        frame = cv2.circle(frame, (a, b), 5, color, -1)
        signature_x[signature_frames] = a
        signature_y[signature_frames] = b

    img = cv2.add(frame, mask)

    return img, frame_gray, good_new.reshape(-1, 1, 2), signature, signature_x, signature_y

# Method to detect fingertip
def detect_fingertip(signature_start_index, frame):
    lower = np.array([0, 48, 0], dtype="uint8")
    upper = np.array([20, 255, 255], dtype="uint8")

    # Draw center mass
    cv2.circle(frame, signature_start_index, 11, [0, 0, 250], 3)
    cv2.putText(frame, 'Place fingertip at red circle', (90, 25), 1, 2, color=1, thickness=2)

    # Blur the image
    image_blur = cv2.GaussianBlur(frame, (3, 3), 0)

    # Convert to HSV
    image_hsv = cv2.cvtColor(image_blur, cv2.COLOR_BGR2HSV)

    # Create mask to detect skin
    skinMask = cv2.inRange(image_hsv, lower, upper)

    # Create mask
    ellipse_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (11, 11))

    # Morphological Operations
    skinMask = cv2.erode(skinMask, ellipse_kernel, iterations=2)
    skinMask = cv2.dilate(skinMask, ellipse_kernel, iterations=2)

    # Blur the mask
    skinMask = cv2.GaussianBlur(skinMask, (3, 3), 0)

    # Background subtraction
    skin = cv2.bitwise_and(frame, frame, mask=skinMask)

    # Convert to Gray scale to find threshold
    skin = cv2.cvtColor(skin, cv2.COLOR_BGR2GRAY)

    # Binary threshold
    ret, thresh = cv2.threshold(skin, 0, 255, cv2.THRESH_BINARY)

    # Getting contours of the filtered frame
    im, contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # Getting the areas of all contours
    areas = [cv2.contourArea(c) for c in contours]

    # If no contour in image
    if len(areas) == 0:
        return signature_start_index, frame, False

    # Getting the index of largest contour
    max_index = areas.index(max(areas))

    # Biggest Contour
    largest_contour = contours[max_index]

    # Draw Contours
    cv2.drawContours(frame, contours, max_index, (0, 0, 255), 1)

    # Find convex defects
    contour_points_indices = cv2.convexHull(largest_contour, returnPoints=False)
    convexity_defects = cv2.convexityDefects(largest_contour, contour_points_indices)

    # Find moments of the largest contour
    moments = cv2.moments(largest_contour)

    # Central mass of first order moments
    if moments['m00'] != 0:
        cx = int(moments['m10'] / moments['m00'])  # cx = M10/M00
        cy = int(moments['m01'] / moments['m00'])  # cy = M01/M00
    center_mass = (cx, cy)

    # Finding distacnce from convexity defect
    far_distances = []
    for i in range(convexity_defects.shape[0]):
        s, e, f, d = convexity_defects[i, 0]
        far = tuple(largest_contour[f][0])
        far_distances.append(far)

    # Draw center mass
    cv2.circle(frame, center_mass, 7, [150, 50, 250], 3)
    cv2.putText(frame, 'Center of Mass', (center_mass), 1, 1, color=1)

    # Calculating distance between far convexity defect and center of mass
    distance_defect_center = []
    for far_dist in far_distances:
        distance = np.hypot(far_dist[0] - center_mass[0], far_dist[1] - center_mass[1])
        distance_defect_center.append(distance)

    # Calculate farthest point
    farthest_point_index = distance_defect_center.index(max(distance_defect_center))
    fingertip = far_distances[farthest_point_index]

    # Creating a circle at fingertip
    cv2.circle(frame, fingertip, 7, [100, 250, 250], 7)

    return fingertip, frame, True

# Method to match two signatures
def predictby_dtw(n):
    file1 = open("Rastogi_signature_12.txt", "r").readlines()
    file2 = open("Rastogi_signature_13.txt", "r").readlines()

    signature1_x = np.zeros(n)
    signature1_y = np.zeros(n)
    signature2_x = np.zeros(n)
    signature2_y = np.zeros(n)

    for i in range(n):
        signature1_x[i], signature1_y[i] = file1[i].split(',')
        signature2_x[i], signature2_y[i] = file2[i].split(',')

    dist_x, cost_x, path_x = dtw(signature1_x, signature2_x, dist=lambda x, y: np.linalg.norm(x - y, ord=1))
    dist_y, cost_y, path_y = dtw(signature1_y, signature2_y, dist=lambda x, y: np.linalg.norm(x - y, ord=1))

    print("Distance : " + str(dist_x + dist_y))

    if dist_x+dist_y < 8:
        print("Signatures match.")
    else:
        print("Signatures does not match.")

if __name__ == '__main__':
    # Varibale to trigger video record, signature record and signature matching
    video_record = True
    signature_record = True
    match_signature = True

    file_name = 'signature2.txt'
    img_name = 'signature2.jpg'
    video_name = 'output2.mp4'

    win_x, win_y = 500, 1000

    # Define the codec and create VideoWriter object
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # Be sure to use lower case
    out = cv2.VideoWriter(video_name, fourcc, 20.0, (win_y, win_x))

    # Signature frames counter
    signature_frames = 0
    max_signature_frames = 200

    # Variables to save coordinates of Signature
    signature_x = np.zeros(max_signature_frames)
    signature_y = np.zeros(max_signature_frames)

    # Start Camera
    video = cv2.VideoCapture(0)

    # Coordinates of the start index of signature
    signature_start_index = 75, 300

    fingertip_present = False
    old_gray = None

    # Parameters for lucas kanade optical flow
    lk_params = dict(winSize=(15, 15),
                     maxLevel=2,
                     criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03))

    mask = np.zeros(shape=(win_x, win_y, 3), dtype='uint8')
    signature = np.zeros(shape=(win_x, win_y, 3), dtype='uint8')

    while(True):
        ret, frame = video.read()
        frame = frame[0:win_x, 0:win_y]
        frame = cv2.flip(frame, 1)

        # 'ESC' Key Event
        key_pressed = cv2.waitKey(5) & 0xFF

        # Break if 'ESC' key is pressed
        if key_pressed == 27:
            break

        if not fingertip_present:
            fingertip, output_frame, fingertip_present = detect_fingertip((signature_start_index), frame)

            cv2.imshow("FingerTip", output_frame)

            if not fingertip_present:
                continue

            elif (fingertip[0] > (signature_start_index[0] - 10)) and (fingertip[0] < (signature_start_index[0] + 10)) \
                and (fingertip[1] > (signature_start_index[1] - 10)) and (fingertip[1] < (signature_start_index[1] + 10)):
                fingertip = np.array([[fingertip]], dtype='float32')
                old_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                print("Done with tip location")

            else:
                fingertip_present = False
        else:
            img, old_gray, fingertip, signature, signature_x, signature_y = track_fingertip(fingertip, frame,
                                    old_gray, mask, lk_params, signature, signature_frames, signature_x, signature_y)
            signature_frames+=  1
            cv2.imshow("Result", img)

            if video_record:
                out.write(frame)

            if signature_frames == max_signature_frames:
                break

    # Release Video, Video Recording and destroy all windows
    video.release()
    out.release()
    cv2.destroyAllWindows()

    # Save signature image
    if signature_record and fingertip_present:
        cv2.imwrite(img_name, signature)
        file = open(file_name, 'w')
        for i in range(max_signature_frames):
            file.write(str(signature_x[i]) + "," + str(signature_y[i]) + "\n")
        file.close()

    if match_signature:
        predictby_dtw(200)

    gc.collect()