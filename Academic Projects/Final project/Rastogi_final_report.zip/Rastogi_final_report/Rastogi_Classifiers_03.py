'''
============================================================================
Following python code will train NN, SVM and kNN on the MNIST dataset.
And saves all 3 classifiers on disk.

Author : Akash Rastogi
Date   : 14th April 2017
============================================================================
'''

from __future__ import print_function

import keras
import numpy as np
import matplotlib.pyplot as plt
import sys

from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.optimizers import RMSprop
from sklearn.neighbors import KNeighborsClassifier
from sklearn import svm, metrics
from sklearn.externals import joblib
from datetime import datetime

def train_knn(train_data, train_labels, test_data, test_labels):
    knn_classifier = KNeighborsClassifier(n_neighbors=3)
    knn_classifier.fit(train_data, train_labels)
    knn_prediction = knn_classifier.predict(test_data)
    joblib.dump(knn_classifier, 'Rastogi_knn_classifier_06.pkl')

    correct_classified = np.count_nonzero(knn_prediction == test_labels)
    accuracy = correct_classified * 100.0 / len(knn_prediction)

    print("Confusion matrix for kNN :\n%s" % metrics.confusion_matrix(knn_prediction, test_labels))
    print(correct_classified)
    print(accuracy)


def train_svm(train_data, train_labels, test_data, test_labels):
    svm_classifier = svm.SVC()
    svm_classifier.fit(train_data, train_labels)
    svm_prediction = svm_classifier.predict(test_data)
    joblib.dump(svm_classifier, 'Rastogi_svm_classifier_07.pkl')

    correct_classified = np.count_nonzero(svm_prediction == test_labels)
    accuracy = correct_classified * 100.0 / len(svm_prediction)

    print("Confusion matrix for SVM :\n%s" % metrics.confusion_matrix(svm_prediction, test_labels))
    print(correct_classified)
    print(accuracy)


def train_cnn(train_data, train_labels, test_data, test_labels):
    batch_size = 128
    num_classes = 10
    epochs = 20

    # convert class vectors to binary class matrices
    train_labels = keras.utils.to_categorical(train_labels, num_classes)
    test_labels = keras.utils.to_categorical(test_labels, num_classes)

    model = Sequential()
    model.add(Dense(512, activation='relu', input_shape=(784,)))
    model.add(Dropout(0.2))
    model.add(Dense(512, activation='relu'))
    model.add(Dropout(0.2))
    model.add(Dense(10, activation='softmax'))
    model.summary()

    model.compile(loss='categorical_crossentropy',
                  optimizer=RMSprop(),
                  metrics=['accuracy'])

    history = model.fit(train_data, train_labels,
                        batch_size=batch_size,
                        epochs=epochs,
                        verbose=1,
                        validation_data=(test_data, test_labels))

    # summarize history for accuracy
    plt.plot(history.history['acc'])
    plt.plot(history.history['val_acc'])
    plt.title('model accuracy')
    plt.ylabel('accuracy')
    plt.xlabel('epoch')
    plt.legend(['train', 'test'], loc='upper left')
    plt.show()

    # summarize history for loss
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.title('model loss')
    plt.ylabel('loss')
    plt.xlabel('epoch')
    plt.legend(['train', 'test'], loc='upper left')
    plt.show()

    # serialize model to JSON
    model_json = model.to_json()
    with open("Rastogi_cnn_classifier_model_08.json", "w") as json_file:
        json_file.write(model_json)

    # serialize weights to HDF5
    model.save_weights("Rastogi_cnn_classifier_weights_09.h5")

if __name__ == '__main__':
    # Changing standard output to file
    sys.stdout = open('Rastogi_ClassifiersLog_05.txt', 'w')

    print(__doc__)

    # Reading mnist Dataset of Keras
    (train_data, train_labels), (test_data, test_labels) = mnist.load_data()

    # Reshape and Normalize
    train_data = train_data.reshape(len(train_data), 784)
    train_data = train_data.astype('float32')
    train_data /= 255

    # Reshape and Normalize
    test_data = test_data.reshape(len(test_data), 784)
    test_data = test_data.astype('float32')
    test_data /= 255

    print("===========================================================================================")
    print("Starting kNN Training : " , datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    train_knn(train_data, train_labels, test_data, test_labels)
    print("===========================================================================================")

    print("===========================================================================================")
    print("Starting SVM Training : ", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    train_svm(train_data, train_labels, test_data, test_labels)
    print("===========================================================================================")

    print("===========================================================================================")
    print("Starting NN Training : ", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    train_cnn(train_data, train_labels, test_data, test_labels)
    print("===========================================================================================")

    print("Finished with all three classifiers : ", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))